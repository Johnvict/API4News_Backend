<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Exchangerate extends Model
{
    //
}
