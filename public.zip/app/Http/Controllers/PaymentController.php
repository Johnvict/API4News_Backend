<?php

namespace App\Http\Controllers;

// use Paystack;
use Illuminate\Http\Request;
// use Unicodeveloper\Paystack\Facades\Paystack;
use Unicodeveloper\Paystack\Paystack;
use App\User;
// use App\Http\Controllers\TransactionController;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\InvoiceController;

class PaymentController extends Controller
{
    public function __construct()
    {
        $this->invoiceCtrl = new InvoiceController();
    }
    public function getInvoice($reference)
    {
        $invoice = $this->invoiceCtrl->index($reference);

        if (!$invoice) {
            return response()->json(['error' => 'invoice not found']);
        }

        /**
         * @param Price
         * Note that the price set here is still in Dollars
         * We should therefore make findings on how Paystack does international payment
         * Meanwhile, we would convert the payment to Naira , then Kobo too
         */
        $totalPrice = $invoice->price * 100;
        $addedByPaystack = $totalPrice * 0.015;

        if ($totalPrice > 250000) {
            $addedByPaystack += 10000;
        }

        $totalPricePlusCharges = $totalPrice + $addedByPaystack;
        $email = $invoice->client->user->email;

        return view('payment')->with([
            "subscriptionType" => $invoice->subtype->title,
            'totalPrice' => $totalPrice,
            'totalPricePlusCharges' => $totalPricePlusCharges,
            'email' => $email,
            'reference' => $invoice->reference,
            'orderId' => $invoice->id,
            'addedByPaystack' => $addedByPaystack
        ]);
    }

    /**
     * Redirect the User to Paystack Payment Page
     * @return Url
     */
    public function redirectToGateway(Request $request)
    {
        $this->Paystack = new Paystack();
        return $this->Paystack->getAuthorizationUrl()->redirectNow($request);
    }

    /**
     * Obtain Paystack payment information
     * @return void
     */
    public function handleGatewayCallback()
    {
        $paymentDetails = $this->Paystack->getPaymentData();

        // return response()->json([
        //     'Data' => $paymentDetails['data']['status'],
        //     'status' => $paymentDetails['data']['status'],
        //     'amount' => $paymentDetails['data']['amount'],
        //     'reference' => $paymentDetails['data']['reference'],
        //     'receipId' => $paymentDetails['data']['id'],
        //     'custumerEmail' => $paymentDetails['data']['customer']['email']
        // ]);

        // $complete = TransactionController::confirmPayment($paymentDetails);
            $complete = true;
        // dd($paymentDetails);

        return response()->json($paymentDetails);

        if ($complete == true) {
            return response()->json(['success' => true]);
        } else {
            return response()->json(['success' => false]);
        }
        // Now you have the payment details,
        // you can store the authorization_code in your db to allow for recurrent subscriptions
        // you can then redirect or do whatever you want
    }


}
