<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Subscription;
use App\Subtype;
use Carbon\Carbon;
use App\Country;
use Illuminate\Support\Facades\Auth;

class SubsController extends Controller
{
    public function index($id)
    {
        $sub = Subscription::find($id);
        return $sub;
    }

    public function all()
    {
        $sub = Auth::User()->client->subscription;

        if ($sub != null) {
            $sub->categories = explode("|", $sub->categories);
            $countries = array(explode("|", $sub->countries));
            $sub->expired = new Carbon('today') > $sub->expiry ? true : false;
            foreach ($countries as $country) {
                $sub->countries = Country::find($country);
            }
            $sub->subtype;
        }

        return $sub;
    }

    public function create(Request $req) {
        $newSub = new Subscription();
        $newSub->client_id = $req->client_id;
        $newSub->subtype_id = $req->subtype_id;
        $newSub->price = 0;
        $newSub->span = $req->span;
        $newSub->countries = $req->countries;
        $newSub->categories = $req->categories;
        $newSub->expiry = $req->expiry;

        $otherSubsToDelete =  Subscription::whereClientId($req->client_id)->pluck('id');
        if($otherSubsToDelete) {
            Subscription::destroy($otherSubsToDelete);
        }

        $newSub->save();
        return $this->returner(201, $this->all());
    }

    public function store(Request $request)
    {
        $sub = new Subscription();
        $sub->client_id = $request->client_id;
        $sub->subtype_id = $request->subtype_id;
        $sub->invoice_id = $request->id;
        $sub->price = $request->price;
        $sub->span = $request->span;
        $sub->countries = $request->countries;
        $sub->categories = $request->categories;
        $sub->expiry =  $request->expiry;

        if ($sub->save()) {
            return $this->returner(201, $this->all());
        }
    }

    public function update(Request $request, $id)
    {
        //
    }

    public function destroy($id)
    {
        //
    }

    public function returner($code, $sub)
    {
        return response()->json(['subscription' => $sub, 'subComplete' => true], $code);
    }
}
