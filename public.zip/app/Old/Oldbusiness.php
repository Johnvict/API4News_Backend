<?php

namespace App\Old;

use Illuminate\Database\Eloquent\Model;

class Oldbusiness extends Model
{
    //
}
