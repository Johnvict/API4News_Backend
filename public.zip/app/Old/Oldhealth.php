<?php

namespace App\Old;

use Illuminate\Database\Eloquent\Model;

class Oldhealth extends Model
{
    //
}
