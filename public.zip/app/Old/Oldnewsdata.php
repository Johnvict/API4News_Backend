<?php

namespace App\Old;

use Illuminate\Database\Eloquent\Model;

class Oldnewsdata extends Model
{
    //
}
