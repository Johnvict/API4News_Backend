<?php

namespace App\Old;

use Illuminate\Database\Eloquent\Model;

class Oldtechnology extends Model
{
    //
}
