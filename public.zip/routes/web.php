<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::post('/pay', 'PaymentController@redirectToGateway')->name('pay');

// Route::get('payment/callback', 'PaymentController@handleGatewayCallback');

// Route::get('pay/{reference}', [
//     'uses' => 'PaymentController@getInvoice',
//     'as' => 'pay-invoice'
// ]);


Route::get('/', function () {
    return view('welcome');
});

Route::get('/', function () {
    return view('welcome');
})->name('homeUrl');


Route::get('news', function() {
    return view('news');
});

Auth::routes();

// Route::get('/home', 'HomeController@index')->name('home');

Route::get('/day', function(){
    $year = date("Y");
    $month = date("F");
    $day = date("d");


    $months = array('August', 'September', 'October');

    $a = array_rand($months, 1);
    // return $months[$a];

    // $date = date_parse("2018-10-12 12:57:41");
    $date = date_create("2018-10-12 10:57:41");
    // return date_format($date, "F d, Y - H:ia");
    return $month.' '.$day.' '.$year;
});
