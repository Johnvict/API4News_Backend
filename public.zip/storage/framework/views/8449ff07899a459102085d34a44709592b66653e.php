<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    
    <link rel="stylesheet" type="text/css" href="http://localhost:8000/newsClient/styles/unique.css">
    
    <title>Document</title>
</head>
<body>
    <div class="container">
        <div class="news" id=api4news></div>
    </div>

    <!-- Include these just before the closing of the body tag -->
    <script src="http://localhost:8000/newsClient/master.js"></script>
    <script src="http://localhost:8000/newsClient/news.js"></script>
</body>
</html>
