<title>Continue to checkout</title>

<style>
    .pageCenter {
        margin: auto auto;
        padding: auto auto;
        /* padding-top:  20%; */
        /* padding-buttom:  10%; */
    }
    .center {
        display: block;
        margin: auto auto;
    }
    .logoImg {
        /* background-image: url("images/unique.png"); */
        width: 80px; padding: 5px; border-radius: 3px; background-color: #fff;
        box-shadow: 0px 4px 4px -4px rgba(0,0,0,0.75);
        -webkit-box-shadow: 0px 4px 4px -4px rgba(0,0,0,0.75);
        -moz-box-shadow: 0px 4px 4px -4px rgba(0,0,0,0.75);
        margin-bottom: 10px;
        cursor: pointer;
        bor
    }
</style>

<div class="pageCenter">
    <?php $__env->startSection('content'); ?>
    <br><br>
    <div class="container">
        <div>
            <img src="/images/unique.png" alt="Ade Unique" class="logoImg">
            
            <h3>News | AdeUnique</h3>

        <div class="center">
            <br><br><hr>
            <div class="container">
                <div class="alert">
                    <h5>Subcription Data</h5>
                    Subscription Type: <?php echo e($subscriptionType); ?> <br>
                    Total Price: <?php echo e($totalPrice); ?> <br>
                    Payment Charges: <?php echo e($addedByPaystack); ?> <br>
                    Total Amount to pay:  <?php echo e($totalPricePlusCharges); ?> <br>
                </div>
                </div>
            </div>
        
              <p>..bringing news to you with ease!</p>
        </div>


        <form method="POST" action="<?php echo e(route('pay')); ?>" accept-charset="UTF-8" class="form-horizontal" role="form">
                <div class="row" style="margin-bottom:40px;">
                  <div class="center col-lg-8 col-md-12 col-sm-12">
                    <input type="hidden" name="email" value="<?php echo e($email); ?>"> 
                    <input type="hidden" name="orderID" value="orderId">
                  <input type="hidden" name="amount" value="<?php echo e($totalPricePlusCharges); ?>"> 
                    
                    <input type="hidden" name="quantity" value="1">
                    <input type="hidden" name="reference" value="<?php echo e($reference); ?>"> required
                    
                    <input type="hidden" name="key" value="<?php echo e(config('paystack.secretKey')); ?>"> 
                    <?php echo e(csrf_field()); ?>


                     

                    <p>
                      <button class="btn btn-success btn-lg btn-block center" type="submit" value="Pay Now">
                      <i class="fa fa-plus-circle fa-lg"></i> Pay Now!
                      </button>
                    </p>
                  </div>
                </div>
        </form>

      </div>
    <?php $__env->stopSection(); ?>
</div>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>